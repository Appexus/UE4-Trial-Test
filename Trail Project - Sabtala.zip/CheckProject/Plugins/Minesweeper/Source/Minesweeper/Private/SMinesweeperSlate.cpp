// Copyright 2022 Sabtala. All Rights Reserved.


#include "SMinesweeperSlate.h"

#include "Widgets/Input/SButton.h"
#include "Widgets/Input/SCheckBox.h"
#include "Widgets/Text/STextBlock.h"
#include "EditorStyleSet.h"
#include "Modules/ModuleManager.h"

#include "PropertyEditorModule.h"
#include "SlateOptMacros.h"




#define LOCTEXT_NAMESPACE "MinesweeperSlate"

BEGIN_SLATE_FUNCTION_BUILD_OPTIMIZATION
void SMinesweeperSlate::Construct(const FArguments& InArgs)
{	
	GameStateText = FText(LOCTEXT("TileText", "NEW GAME"));

	ChildSlot
	[
		SNew(SVerticalBox)

		+ SVerticalBox::Slot()
		.FillHeight(1.0f)		
		.HAlign(HAlign_Fill)
		.VAlign(VAlign_Fill)
		[
			SNew(SBorder)
			.Padding(FMargin(6.f, 2.f))
			[
				SNew(SVerticalBox)

				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Fill)
				.Padding(FMargin(0.f, 5.f))
				[
					SNew(SHorizontalBox)
					+ SHorizontalBox::Slot()
					.FillWidth(1)
					[
						//Width
						SNew(SHorizontalBox)
						+ SHorizontalBox::Slot()
						.HAlign(HAlign_Left)
						.AutoWidth()
						[
							SNew(STextBlock)
							.Text(LOCTEXT("WidthText", "Width:"))
						]
						+ SHorizontalBox::Slot()
						.HAlign(HAlign_Fill)
						.Padding(FMargin(10.f, 0.f))
						[
							SAssignNew(WidthBox, SEditableTextBox)							
						]												
					]

					+ SHorizontalBox::Slot()
					.FillWidth(1)
					[
						//Height
						SNew(SHorizontalBox)
						+ SHorizontalBox::Slot()
						.HAlign(HAlign_Left)
						.AutoWidth()
						[
							SNew(STextBlock)
							.Text(LOCTEXT("HeigthText", "Height:"))
						]
						+ SHorizontalBox::Slot()
						.HAlign(HAlign_Fill)
						.Padding(FMargin(10.f, 0.f))
						[
							SAssignNew(HeightBox, SEditableTextBox)							
						]					
					]
				]

				//Number of mines
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Fill)
				.Padding(FMargin(0.f, 5.f))
				[
					SNew(SHorizontalBox)
					+SHorizontalBox::Slot()
					.FillWidth(1)
					[
						
						SNew(SHorizontalBox)
						+ SHorizontalBox::Slot()
						.HAlign(HAlign_Left)
						.AutoWidth()
						[
							SNew(STextBlock)
							.Text(LOCTEXT("NumMineText", "Number Of Mines:"))
						]
						+ SHorizontalBox::Slot()
						.HAlign(HAlign_Fill)
						.Padding(FMargin(10.f, 0.f))						
						[
							SAssignNew(NumMineBox, SEditableTextBox)							
						]
					]
				]

				//Generate Grid button
				+ SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Fill)
				.Padding(FMargin(0.f, 5.f))
				[
					SNew(SVerticalBox)
					+SVerticalBox::Slot()
					.HAlign(HAlign_Center)
					
					[
						SNew(SButton)
						.HAlign(EHorizontalAlignment::HAlign_Center)
						.Text(LOCTEXT("GenerateButtonLabel", "Generate New Grid"))
						.ToolTipText(LOCTEXT("GenerateButtonLabel_ToolTip", "Generate a grid with x number of tiles on the width and height"))
						.OnClicked_Lambda([this]()
							{
								GenerateButtonClicked();
								return FReply::Handled();
							}
						)
					]
					
				]

				//Game State
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(FMargin(0.f, 5.f))
				[
					SAssignNew(StateText, STextBlock)
					.Text(GameStateText)					
				]

				//Grid
				+ SVerticalBox::Slot()
				.AutoHeight()
				.Padding(FMargin(0.f, 5.f))
				.HAlign(HAlign_Left)
				.VAlign(VAlign_Top)
				[					
					SAssignNew(UniformGrid, SUniformGridPanel)						
				]
			]
		]

	];
}
SMinesweeperSlate::~SMinesweeperSlate()
{
}
END_SLATE_FUNCTION_BUILD_OPTIMIZATION

void SMinesweeperSlate::GenerateButtonClicked()
{
	RefreshWidgetTile();
	
	// Lets record the input values
	FString WB = WidthBox->GetText().ToString();
	WidthNumber = FCString::Atoi(*WB);

	FString HB = HeightBox->GetText().ToString();
	HeightNumber = FCString::Atoi(*HB);

	FString MN = NumMineBox->GetText().ToString();
	MineNumber = FCString::Atoi(*MN);

	//Grid(height, width)
	
	//Create the Grid int32 Widthindex = 0; Widthindex < WidthNumber; Widthindex++
	for (int32 Widthindex = 0; Widthindex < WidthNumber; Widthindex++)
	{
		for (int32 Heightindex = 0; Heightindex < HeightNumber; Heightindex++)
		{
			UniformGrid->AddSlot(Heightindex, Widthindex)
			[
				SNew(SVerticalBox)
				
				+SVerticalBox::Slot()
				.HAlign(HAlign_Fill)
				[
					SAssignNew(CustomTileButton, STileButton, SharedThis(this))					
				]	
			];

			TileButtons.Add(CustomTileButton);
			SpreadValue++;
		}
		SpreadValue = 0;
	}

	//Reset Game State if necessary
	bIsGameOver = false;
	UpdateGameState();
	
}

void SMinesweeperSlate::RefreshWidgetTile()
{
	UniformGrid->ClearChildren();
	TileButtons.Reset();
	return;
}

EVisibility SMinesweeperSlate::GetTileLabelVisibility(TSharedPtr<SButton> InTileButton) const
{
	//We only want the clicked/similar buttons to be visible
	bool WasPressed = false;
	if (InTileButton.IsValid() && InTileButton->IsPressed())
	{
		WasPressed = true;
	}
	
	if (WasPressed)
	{
		return EVisibility::Visible;
	}
	else
	{
		return EVisibility::Hidden;
	}
}

void SMinesweeperSlate::AButtonWasClicked(TSharedPtr<STileButton> InButton)
{
	for (auto& Button : TileButtons)
	{
		if (Button->Labbel == InButton->Labbel)
		{
			Button->ShowLabel = true;
		}
	}
	
	FString Bomb = "BB";
	if (InButton->Labbel == Bomb)
	{
		bIsGameOver = true;
	}

	UpdateGameState();
}

void SMinesweeperSlate::UpdateGameState()
{
	//Check the game state
	bIsGameOver ? GameState = "GAME OVER!!!" : GameState = "NEW GAME";
	GameStateText = FText::Format(LOCTEXT("TileText", "{0}"), FText::FromString(GameState));

	StateText->SetText(GameStateText);
}



/**
* Lets create a custom SButton to have special functionality
*/
void STileButton::Construct(const FArguments& InArgs, TSharedPtr<class SMinesweeperSlate> InSlate)
{
	Slate = InSlate;

	//Every button should have a random label
	int32 Rand = FMath::RandRange(0, 5);
	
	switch (Rand)
	{
	default:
		break;
	case 0:
		Labbel = "1";
		break;
	case 1:
		if (Slate->WidthNumber > 10)
		{
			if (Slate->MineNumber && Slate->SpreadValue > 3)
			{
				Labbel = "BB";
				Slate->MineNumber--;
			}
			else
			{
				Labbel = "1";
			}
		}
		else
		{
			if (Slate->MineNumber)
			{
				Labbel = "BB";
				Slate->MineNumber--;
			}
			else
			{
				Labbel = "1";
			}			
		}
		break;
	case 2:
		Labbel = "2";
		break;
	case 3:
		Labbel = "3";
		break;
	case 4:
		Labbel = "4";
		break;

	case 5:
		Labbel = "5";
		break;
	}
	
	FText LabText = FText::Format(LOCTEXT("TileText", "{0}"),FText::FromString(Labbel));

	SButton::Construct(SButton::FArguments()
		.HAlign(EHorizontalAlignment::HAlign_Center)
		.OnClicked_Lambda([this]()
			{
				ShowLabel = true;
				ButtonClicked();
				return FReply::Handled();
			}
		)
		[
			SNew(STextBlock)
			.Visibility(this, &STileButton::GetLabelVisibility)
			.Text(LabText)
		]
	);
		
}

EVisibility STileButton::GetLabelVisibility() const
{
	if (ShowLabel)
	{
		return EVisibility::Visible;
	}
	else
	{
		return EVisibility::Hidden;
	}
}

void STileButton::ButtonClicked()
{
	Slate->AButtonWasClicked(SharedThis(this));
}
#undef LOCTEXT_NAMESPACE