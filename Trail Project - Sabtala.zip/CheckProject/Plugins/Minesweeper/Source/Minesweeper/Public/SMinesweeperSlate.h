// Copyright 2022 Sabtala. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Layout/Visibility.h"
#include "Input/Reply.h"
#include "Widgets/DeclarativeSyntaxSupport.h"
#include "Widgets/SWidget.h"
#include "Widgets/SCompoundWidget.h"
#include "Widgets/Layout/SUniformGridPanel.h"


#include "Misc/Attribute.h"

/** A class representing each tile button */
class STileButton : public SButton
{
public:
	SLATE_BEGIN_ARGS(STileButton) {}
	SLATE_END_ARGS()
	
	void Construct(const FArguments& InArgs, TSharedPtr<class SMinesweeperSlate> InSlate);

	/** Should the label be displayed? */
	bool ShowLabel = false;

	/** Gets the visibility of the tile labels */
	EVisibility GetLabelVisibility() const;

	TSharedPtr<class SMinesweeperSlate> Slate;

	/** Send Info that this button was clicked */
	void ButtonClicked();

	/** Label for this button */
	FString Labbel;

};


class SMinesweeperSlate : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SMinesweeperSlate) {}
	//SLATE_ARGUMENT(FNaaturEdMode*, NaaturEdMode)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);
	~SMinesweeperSlate();

	/** This gives every button on the tile a random label */
	void SetButtonLabel();

	/** Check the label of the clicked button */
	void GenerateButtonClicked();

	/** Refreshes the tile */
	void RefreshWidgetTile();

	/** Gets the visibility of the tile labels */
	EVisibility GetTileLabelVisibility(TSharedPtr<SButton> InTileButton) const;

	/** Called when a button in the grid is clicked */
	void AButtonWasClicked(TSharedPtr<STileButton> InButton);

	/** Game state displayed on slate */
	FString GameState;
	FText GameStateText;

	/** Was a mine clicked? */
	bool bIsGameOver = false;

	/** Check State of the game */
	void UpdateGameState();

	/** Number of mines inputed */
	int32 MineNumber;

	/** Number of buttons for the width */
	int32 WidthNumber;

	/** Number of buttons for the height */
	int32 HeightNumber;

	/** Number of mines inputed */
	int32 SpreadValue = 0;

private:
	/** Value of the width */
	TSharedPtr<SEditableTextBox> WidthBox;

	/** Value of the Height */
	TSharedPtr<SEditableTextBox> HeightBox;

	/** Value of the number of mines */
	TSharedPtr<SEditableTextBox> NumMineBox;

	/** A single button in the grid */
	TSharedPtr<STileButton> CustomTileButton;

	/** An array of all the buttons in the grid */
	TArray<TSharedPtr<STileButton>> TileButtons;

	/** The grid holding the buttons */
	TSharedPtr<SUniformGridPanel> UniformGrid;

	/** Displayed game state */
	TSharedPtr<STextBlock> StateText;

};